/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lenovo
 */
class Pro {
    
    private int p_id,u_id;
    private String p_pollution,p_place,p_description;
    
    public Pro(int p_id,int u_id,String p_pollution,String p_place,String p_description)
    {
        this.p_id=p_id;
        this.u_id=u_id;
        this.p_pollution=p_pollution;
        this.p_place=p_place;
        this.p_description=p_description;
        
    }
    public int getp_id()
    {
        return p_id;
    }
     public int getu_id()
    {
        return u_id;
    }
      public String getp_pollution()
    {
        return p_pollution;
    }
       public String getp_place()
    {
        return p_place;
    }
        public String getp_description()
    {
        return p_description;
    }
    
}
