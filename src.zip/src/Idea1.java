/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lenovo
 */
class Idea1 {
    
    private int i_id,u_id;
    private String i_pollution,i_description;
    
    public Idea1(int i_id,int u_id,String i_pollution,String i_description)
    {
        this.i_id=i_id;
        this.u_id=u_id;
        this.i_pollution=i_pollution;
        this.i_description=i_description;
        
    }
    public int geti_id()
    {
        return i_id;
    }
     public int getu_id()
    {
        return u_id;
    }
      public String geti_pollution()
    {
        return i_pollution;
    }
       public String geti_description()
    {
        return i_description;
    }
        
    
}
