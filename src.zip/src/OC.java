/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lenovo
 */
class OC {
    private int e_id;
    private String o_status,o_description;
    
    public OC(int e_id,String o_status,String o_description)
    {
        this.e_id=e_id;
        this.o_status=o_status;
        this.o_description=o_description;
        
    }
    public int gete_id()
    {
        return e_id;
    }
       public String geto_status()
    {
        return o_status;
    }
        public String geto_description()
    {
        return o_description;
    }
}
